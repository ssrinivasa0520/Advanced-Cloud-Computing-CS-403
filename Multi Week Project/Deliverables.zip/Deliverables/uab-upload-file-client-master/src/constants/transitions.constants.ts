export const Variant = {
  FADE: {
    visible: { opacity: 1 },
    hidden: { opacity: 0 },
  },
};
