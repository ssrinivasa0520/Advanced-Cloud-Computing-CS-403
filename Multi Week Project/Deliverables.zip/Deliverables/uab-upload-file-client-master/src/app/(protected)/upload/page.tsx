import UploadPage from "@/components/pages/UploadPage";

const Upload = () => {
  return <UploadPage />;
};

export default Upload;
