'use client'

import useLogout from "@/hooks/useLogout";

export default function Logout() {
  useLogout();

  return <></>;
}
