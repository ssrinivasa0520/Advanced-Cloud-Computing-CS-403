import AttachmentPage from "@/components/pages/AttachmentPage";

const Attachments = () => {
  return <AttachmentPage />;
};

export default Attachments;
