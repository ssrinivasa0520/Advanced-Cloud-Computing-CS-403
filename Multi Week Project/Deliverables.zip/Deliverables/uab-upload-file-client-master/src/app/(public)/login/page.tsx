import LoginPage from "@/components/pages/LoginPage";

export default function Home() {
  return (
    <LoginPage />
  )
}
